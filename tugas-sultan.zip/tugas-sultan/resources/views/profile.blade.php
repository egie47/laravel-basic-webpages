<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>halaman</title>

    <style>
        * {
            margin: 0;
            padding: 0;
        }

        header {
            background-color: black;
            color: white;
            padding: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center
        }

        header a {
            color: white
        }

        main {
            padding: 24px
        }

        img {
            width: 120px;
        }
    </style>
</head>

<body>
    <header>
        <h1>
            {{ $nama }}
        </h1>

        <div>
            <a href="/">Home</a>
            <a href="#">Profile</a>
            <a href="/contact-profile">Contact</a>
        </div>
    </header>
    <main>
        <h2>intro</h2>
        <p>
            halo nama saya
            {{$nama}}, umur saya
            {{$umur}}

    </main>
</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>home</title>

    <style>
        * {
            margin: 0;
            padding: 0;
        }

        header {
            background-color: black;
            color: white;
            padding: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center
        }

        header a {
            color: white
        }

        main {
            padding: 24px
        }

        img {
            width: 120px;
        }
    </style>
</head>

<body>
    <header>
        <h1>
            home
        </h1>

        <div>
            <a href="#">Home</a>
            <a href="/profile/nama/umur">Profile</a>
            <a href="/contact-profile">Contact</a>
        </div>
    </header>

    <main>
        <h1>ini adalah home</h1>
    </main>

</body>

</html><?php /**PATH C:\xampp\htdocs\wd_laravel_intermediate\tugas-sultan\resources\views/home.blade.php ENDPATH**/ ?>
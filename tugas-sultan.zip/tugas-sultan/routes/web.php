<?php


use App\Http\Controllers\MyContactController;
use App\Http\Controllers\Homecontroller;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\UserController;

use Illuminate\Support\Facades\Route;


//ketika pengunjung meminta url '/'

route::get('/users/{id}', function ($id) {
    return "User Dengan ID" . $id;
});
//ketika menuliskan alamat di usercontroller
route::get('/users', [UserController::class, 'index']);



route::get('/about', function () {
    echo "hello world";
});

route::get('/', [Homecontroller::class, 'index']);

route::get('/profile/{nama}/{umur}', [ProfileController::class, 'index']);

route::get('/contact-profile', [MyContactController::class, 'index']);

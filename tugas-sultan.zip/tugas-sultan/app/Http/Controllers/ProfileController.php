<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProfileController
{
    public function index($name, $umur)
    {

        return view('profile', [
            'nama' => $name,
            'umur' => $umur,

        ]);
    }
}

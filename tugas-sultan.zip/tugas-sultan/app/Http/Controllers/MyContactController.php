<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MyContactController
{

    public function index()
    {
        return view('contact-profile');
    }
}
